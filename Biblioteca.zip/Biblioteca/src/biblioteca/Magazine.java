/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Daniel
 */
public class Magazine {

    public Integer MgzID;

    public int MagazineAvailability(int itemid) throws IOException {

        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int mgzid = 0;

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("exec spU_magazineavailability ?");
            //ps.setString(1, filter);   

            ps.setInt(1, itemid);

            System.out.println();

            rs = ps.executeQuery();
            while (rs.next()) {
                mgzid = rs.getInt(1);
            }
            rs.close();
            return mgzid;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
            return 0;
        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {
                    System.out.println(ex.getMessage());
                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {
                    System.out.println(ex);
                }
            }
        }

    }
}
