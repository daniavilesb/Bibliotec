/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Daniel
 */
public class NoRequest {

    public Integer NoRequestID;
    public String NoRequestDate;
    public Integer NewAttr;
    

    public void NoRequest(int cardnumber, int kind, int age, int itemid, int itembyuser) throws IOException, ParseException {
        
        Calendar RequestDate = Calendar.getInstance();                
        Magazine mgz = new Magazine();
        ReferenceBook rfbk = new ReferenceBook();
        int resourceid = 0;

        if (kind == 3) {
            resourceid = mgz.MagazineAvailability(itemid);            
        }
        if (kind == 4) {
            resourceid = rfbk.RFAvaliability(itemid);
        }

        int year = RequestDate.get(Calendar.YEAR);
        int month = RequestDate.get(Calendar.MONTH);
        int day = RequestDate.get(Calendar.DAY_OF_MONTH);
        int hour = RequestDate.get(Calendar.HOUR);
        int minute = RequestDate.get(Calendar.MINUTE);
        int second = RequestDate.get(Calendar.SECOND);        

        NoRequestDate = year + "-" + (month + 1) + "-" + day + " " + hour + ":" + minute + ":" + second;

     
        if (kind == 3 || kind == 4) {

            if (age <= 12 && itembyuser != 3 || age > 12) {

                if (kind == 3) {

                    this.Insert_norequest(resourceid, cardnumber, NoRequestDate, 0);
                    JOptionPane.showMessageDialog(null, "This item is not for request just for consult and has to be delivered today" + "\n this is a magazine with reference copy: " + resourceid);

                }

                if (kind == 4) {
                    this.Insert_norequest(0, cardnumber, NoRequestDate, resourceid);
                    JOptionPane.showMessageDialog(null, "This item is not for request just for consult and has to be delivered today" + "\n this is a reference book with reference copy: " + resourceid);

                }

            } else {

                JOptionPane.showMessageDialog(null, "The user is less than 12 years old and has now 3 items requested");

            }

        } else {            

        }

    }

    public void Insert_norequest(int referencebookid, int cardnumber, String norequestdate, int magazineid) throws IOException {
        ResultSet rs;
        SQL.SQLConnection sqlc = new SQL.SQLConnection();
        Connection con = sqlc.Connection();
        Statement stat = null;
        PreparedStatement ps = null;
        int edad = 0;
        String srfbookid, smagazinid;

        if (referencebookid == 0) {
            srfbookid = null;
        } else {
            srfbookid = String.valueOf(referencebookid);
        }
        if (magazineid == 0) {
            smagazinid = null;
        } else {
            smagazinid = String.valueOf(magazineid);
        }

        try {
            // Creamos un Statement para poder hacer peticiones a la bd
            stat = con.createStatement();
            // Insertar 2 filas en la tabla Motor
            ps = con.prepareStatement("spU_InsertnoRequest ?,?,?,?");

            ps.setString(1, norequestdate);
            ps.setString(2, srfbookid);
            ps.setString(3, smagazinid);
            ps.setInt(4, cardnumber);

            rs = ps.executeQuery();

            rs.close();

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());

        } finally {
            if (stat != null) {
                try {
                    stat.close();
                } catch (SQLException ex) {

                }
            }
            if (con != null) {
                try {
                    con.close();

                } catch (SQLException ex) {

                }
            }
        }
    }
}
